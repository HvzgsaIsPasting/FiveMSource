#include <Windows.h>
#include <iostream>
#include <process.h>
#include <thread>
#include <vector>
#include <filesystem>
#include <chrono>
#include <string>
#include <sstream>
#include <fstream>
//#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "user32.lib")
#include <mutex>
#include <map>
#include <unordered_map>
#include <joaat.hpp>