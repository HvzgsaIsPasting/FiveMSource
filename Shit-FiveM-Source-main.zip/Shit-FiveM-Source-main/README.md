# Shit-FiveM-Source
i release this old shit source that is detected, 
i most likely took inspiration for some features from https://github.com/YimMenu/YimMenu/tree/master

it has really cool features like physic gun freecam and more but since my native invoker is detected , using it will result a ban

i know the code but i don't care , i was using it on multiple servers without getting ban 

There is also a Threading system ( made by tabibito ) that is undetected but you can still change it and find another way (we found 7 ways to do it easily)

Made by Sucka2992,Fontesie
