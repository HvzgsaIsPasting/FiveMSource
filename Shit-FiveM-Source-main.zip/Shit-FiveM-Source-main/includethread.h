#pragma once
#include <Windows.h>
#include <iostream>
#include <Windows.h>
//#include <singeton.hpp>
//#include <game.hpp>
//#include <fiber.hpp>
//#include <thread.hpp>

#include <src/fivem/native/invoker.hpp>
#include <hashes.hpp>
#include <PgCollection.h>
#include <ScrCollection.h>
#include "src/fivem/memory/memory.hpp"
#include <RAGEhelper.hpp>