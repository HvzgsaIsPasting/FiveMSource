#pragma once

namespace menu {

	void init_menu();

	void render_menu();

	inline bool show_menu = false;
}